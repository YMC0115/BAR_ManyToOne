
## J:5 persons per cohort;I:24次
I=24;J=5;W=40;maxtime=I*J+W
## Y: simulation runs;Pu:cut-off point;B:burn-in;run: number of MCMC;Z:run-B mua.mub.muc (for Pa.Pb.Pc )
Y=3000;
run=3000;B=1000;Z=run-B
## MCMC 
nalpha=0;nbeta=0
## 
asign1=asign2=asign3=1/3
## prior 
ga1=ga2=ga3=ga4=0.5
alpha=5;beta=1/450 #lambda
eta=300;rho1=2/300;rho2=1.2/300;rho3=1/300;rho4=0.95/300 #theta
## pts of assign to each arm (na nb nc); pts in the best arm (Na Nb Nc)
na=nb=nc=Na=Nb=Nc=0

#
PROBMAT=NULL
MAT=NULL
ACCEPT_RATE=NULL
tmat0=matrix(0,nrow=I*J,ncol=6)
tmat0=rbind(c(1,0,1,1,1,1),c(1,0,1,1,1,1),c(2,0,1,1,1,1),c(2,0,1,1,1,1),c(3,0,1,1,1,1),c(3,0,1,1,1,1),tmat0)
s=c(0,0,0,0,0,0,1:(I*J))

## conditional posterior of theta
## b1:theta;rho;t:survival time;a1:lambda;cen:censored indicator;k0:short-term response
thetapost=function(t,cen,a1,b1,k0){
  if(k0==3){rho=rho1}else if(k0==4){rho=rho2}else if(k0==5){rho=rho3}else{rho=rho4}
  pal=(sum(cen)+eta-1)*log(b1)+log(prod(t^(cen*(b1-1))))+(-a1*(sum(t^b1))-b1/rho)
  if(a1<0|b1<0){pal=0}else{pal=pal}
  pal
}

for(y in 1:Y){
  na=nb=nc=Na=Nb=Nc=0
  tmat=cbind(tmat0,s) %>% data.frame() ; colnames(tmat)=c("Trt","time","k1","k2","k3","k4","s")
  asign1=asign2=asign3=1/3
  for(i in 1:I){
    probmat=c(i,asign1,asign2,asign3)
    PROBMAT=rbind(PROBMAT,probmat)
    for(j in 1:J){
      trt=rmultinom(1,1,c(asign1,asign2,asign3))
      Trt=models(scenario,trt)$Trt
      p1=models(scenario,trt)$p1
      p2=models(scenario,trt)$p2
      p3=models(scenario,trt)$p3
      p4=models(scenario,trt)$p4
      beta1=models(scenario,trt)$beta1
      beta2=models(scenario,trt)$beta2
      beta3=models(scenario,trt)$beta3
      beta4=models(scenario,trt)$beta4
      alpha1=models(scenario,trt)$alpha1
      alpha2=models(scenario,trt)$alpha2
      alpha3=models(scenario,trt)$alpha3
      alpha4=models(scenario,trt)$alpha4
      na=models(scenario,trt)$na
      nb=models(scenario,trt)$nb
      nc=models(scenario,trt)$nc
      
      rm=rmultinom(1,1,c(p1,p2,p3,p4))
      k=t(rm)
      U=runif(1)
      
      if(k[1]==1){lt=(-log(1-U)/alpha1)^(1/beta1)}
      if(k[2]==1){lt=(-log(1-U)/alpha2)^(1/beta2)}
      if(k[3]==1){lt=(-log(1-U)/alpha3)^(1/beta3)}
      if(k[4]==1){lt=(-log(1-U)/alpha4)^(1/beta4)}
      
      tmat[J*(i-1)+j+6,]=c(Trt,lt,k,s[J*(i-1)+j+6])}
    
    ##posterior of px (x=1~4)
    px=function(trt0){##trt=1.2.3
      tmat3=tmat[which(tmat$Trt==trt0),]
      K1=sum(tmat3$k1)-2
      K2=sum(tmat3$k2)-2
      K3=sum(tmat3$k3)-2
      K4=sum(tmat3$k4)-2
      rd=rdirichlet(Z,c(ga1+K1,ga2+K2,ga3+K3,ga4+K4))
      rd
    }
    
    n=na+nb+nc
    if(n<120){
      ##run-B muxk
      muxk=function(trt0,k0){ ##trt0=1,2,3;k0=3,4,5,6
        if(k0==3){b1=2;v=0.43}else if(k0==4){b1=1.2;v=0.26}else if(k0==5){b1=1;v=0.24}else{b1=0.95;v=0.23}##b1:MCMC起始值 v:MCMC 建議函數的variance
        tmat1=tmat[-c(1:6),] %>% filter(.,s<=J*i)
        tmat2=tmat1[tmat1$Trt==trt0&tmat1[,k0]==1,] 
        tmat3=tmat2[which(tmat2$time+tmat2$s<(J*i+1)),] 
        tmat4=tmat2[-which(tmat2$time+tmat2$s<(J*i+1)),] 
        t=c(tmat3$time,(J*i+1)-tmat4$s)
        cen=c(rep(1,dim(tmat3)[1]),rep(0,dim(tmat4)[1]))
        mm=rep(0,run)     
        nbeta=0
        for(x in 1:run){
          a1=rgamma(1,shape=sum(cen)+alpha,scale=1/((1/beta+sum(t^b1))))
          pold2=thetapost(t,cen,a1,b1,k0)
          repeat{
            parjump2=rnorm(1,b1,v)
            if(parjump2>0){break}
          }
          pnew2=thetapost(t,cen,a1,parjump2,k0)
          prob2=min(pnew2-pold2,0)
          if(log(runif(1))<prob2){b1=parjump2;nbeta=nbeta+1}
          else{b1=b1;nbeta=nbeta}
          mm[x]=(a1^(-1/b1))*gamma(1+1/b1)
        }
        accept_rate=nbeta/run
        MM=mm[(B+1):run]
        return(list(accept_rate=accept_rate,MM=MM))
      }}
    
    if(n==120){
      ##run-B muxk
      muxk=function(trt0,k0){ ##trt0=1,2,3;k0=3,4,5,6
        if(k0==3){b1=2;v=0.43}else if(k0==4){b1=1.2;v=0.26}else if(k0==5){b1=1;v=0.24}else{b1=0.95;v=0.23}##b1:MCMC起始值 v:MCMC 建議函數的variance
        tmat1=tmat[-c(1:6),] %>% filter(.,s<=J*i)
        tmat2=tmat1[tmat1$Trt==trt0&tmat1[,k0]==1,] 
        tmat3=tmat2[which(tmat2$time+tmat2$s<maxtime),] 
        tmat4=tmat2[-which(tmat2$time+tmat2$s<maxtime),] 
        t=c(tmat3$time,maxtime-tmat4$s)
        cen=c(rep(1,dim(tmat3)[1]),rep(0,dim(tmat4)[1]))
        mm=rep(0,run)   
        nbeta=0
        for(x in 1:run){
          a1=rgamma(1,shape=sum(cen)+alpha,scale=1/((1/beta+sum(t^b1))))
          pold2=thetapost(t,cen,a1,b1,k0)
          repeat{
            parjump2=rnorm(1,b1,v)
            if(parjump2>0){break}
          }
          pnew2=thetapost(t,cen,a1,parjump2,k0)
          prob2=min(pnew2-pold2,0)
          if(log(runif(1))<prob2){b1=parjump2;nbeta=nbeta+1}
          else{b1=b1;nbeta=nbeta}
          mm[x]=(a1^(-1/b1))*gamma(1+1/b1)
        }
        accept_rate=nbeta/run
        MM=mm[(B+1):run]
        return(list(accept_rate=accept_rate,MM=MM))
      }}
    
    ## 
    
    acc=c(i,
          muxk(1,3)$accept_rate,muxk(1,4)$accept_rate,muxk(1,5)$accept_rate,muxk(1,6)$accept_rate,
          muxk(2,3)$accept_rate,muxk(2,4)$accept_rate,muxk(2,5)$accept_rate,muxk(2,6)$accept_rate,
          muxk(3,3)$accept_rate,muxk(3,4)$accept_rate,muxk(3,5)$accept_rate,muxk(3,6)$accept_rate)
    ACCEPT_RATE=rbind(ACCEPT_RATE,acc)
    
    ### mux ### 
    mux=function(trt0){
      mux=matrix(px(trt0),nrow=Z,ncol=4)%*%matrix(c(muxk(trt0,3)$MM,muxk(trt0,4)$MM,muxk(trt0,5)$MM,muxk(trt0,6)$MM),nrow=4,ncol=Z,byrow=T)
      dmux=diag(mux)
      dmux
    }
    
    mu=t(rbind(mux(1),mux(2),mux(3))) %>% data.frame() ; colnames(mu)=c("mua","mub","muc")
    
    ###############
    
    asign1=methodFN(mu)[1]
    asign2=methodFN(mu)[2]
    asign3=methodFN(mu)[3]
    
    if(n<30){asign1=asign2=asign3=1/3}
    
    ## stopping criteria 
    if(asign1>Pu){Na=Na+1;break}else if(asign2>Pu){Nb=Nb+1;break}
    else if(asign3>Pu){Nc=Nc+1;break}##stop
    
    ###############
    asign1=useFN(fn1,fn2,fn4,asign1,asign2,asign3,na,nb,nc,n,N)[1]
    asign2=useFN(fn1,fn2,fn4,asign1,asign2,asign3,na,nb,nc,n,N)[2]
    asign3=useFN(fn1,fn2,fn4,asign1,asign2,asign3,na,nb,nc,n,N)[3]
    
  }
  
  N=Na+Nb+Nc
  
  mat=c(na,nb,nc,n,Na,Nb,Nc,N,asign1,asign2,asign3,mean(mu$mua),mean(mu$mub),mean(mu$muc))
  print(c(y,mat))
  MAT=rbind(MAT,mat)
}

MACCEPT_RATE = ACCEPT_RATE %>% data.frame() %>% group_by(X1) %>% 
  summarise(acc1=mean(X2),acc2=mean(X3),acc3=mean(X4),acc4=mean(X5),
            acc5=mean(X6),acc6=mean(X7),acc7=mean(X8),acc8=mean(X9),
            acc9=mean(X10),acc10=mean(X11),acc11=mean(X12),acc12=mean(X13))
MPROBMAT = PROBMAT %>% data.frame() %>% group_by(X1) %>% summarise(asign_a=mean(X2),asign_b=mean(X3),asign_c=mean(X4))
MAT=data.frame(MAT) ; colnames(MAT)=c("na","nb","nc","n","Na","Nb","Nc","N","asigna","asignb","asignc","mua","mub","muc")

#=======================================================================
# results
averages <- colMeans(MAT[, c("na", "nb", "nc","Na", "Nb", "Nc", "mua", "mub", "muc")], na.rm = TRUE)
std <- apply(MAT[, c("na", "nb", "nc","Na", "Nb", "Nc","mua", "mub", "muc")], 2, sd)
RESULT <- cbind(round(averages, 3),round(std, 3))

write.csv(MAT,paste0(desktop_path,"MAT_",fn1,"_",fn3,"_",fn2,"_",fn4,"_",Pu,"_",scenario,".csv"))
write.csv(RESULT,paste0(desktop_path,"RESULT_",fn1,"_",fn3,"_",fn2,"_",fn4,"_",Pu,"_",scenario,".csv"))
write.csv(MACCEPT_RATE,paste0(desktop_path,"MACCEPT_RATE_",fn1,"_",fn3,"_",fn2,"_",fn4,"_",Pu,"_",scenario,".csv"))




