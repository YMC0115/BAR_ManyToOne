models<-function(scenario,trt){
  if(scenario==1){
    if(trt[1]==1){Trt=1;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/90;alpha2=1/90;alpha3=1/90;alpha4=1/90;na=na+1}
    else if(trt[2]==1){Trt=2;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/90;alpha2=1/90;alpha3=1/90;alpha4=1/90;nb=nb+1}
    else if(trt[3]==1){Trt=3;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/90;alpha2=1/90;alpha3=1/90;alpha4=1/90;nc=nc+1}
   }
  if (scenario==2){
    if(trt[1]==1){Trt=1;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/90;alpha2=1/90;alpha3=1/90;alpha4=1/90;na=na+1}
    else if(trt[2]==1){Trt=2;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/120;alpha2=1/120;alpha3=1/120;alpha4=1/120;nb=nb+1}
    else if(trt[3]==1){Trt=3;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/140;alpha2=1/140;alpha3=1/140;alpha4=1/140;nc=nc+1}
  
  }
  if (scenario==3){
    if(trt[1]==1){Trt=1;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/90;alpha2=1/90;alpha3=1/90;alpha4=1/90;na=na+1}
    else if(trt[2]==1){Trt=2;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/90;alpha2=1/90;alpha3=1/90;alpha4=1/90;nb=nb+1}

  }
  if(scenario==4){
    if(trt[1]==1){Trt=1;p1=0.4;p2=0.3;p3=0.1;p4=0.2;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/90;alpha2=1/90;alpha3=1/90;alpha4=1/90;na=na+1}
    else if(trt[2]==1){Trt=2;p1=0.2;p2=0.2;p3=0.2;p4=0.4;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/120;alpha2=1/120;alpha3=1/120;alpha4=1/120;nb=nb+1}
    else if(trt[3]==1){Trt=3;p1=0.1;p2=0.1;p3=0.3;p4=0.5;beta1=2;beta2=1.2;beta3=1;beta4=0.95;alpha1=1/140;alpha2=1/140;alpha3=1/140;alpha4=1/140;nc=nc+1}
  }
  
  return(list(Trt=Trt,p1=p1,p2=p2,p3=p3,p4=p4,beta1=beta1,beta2=beta2,beta3=beta3,beta4=beta4,alpha1=alpha1,alpha2=alpha2,alpha3=alpha3,alpha4=alpha4,na=na,nb=nb,nc=nc))
}

