
## The program contains several function to estimate the parameters in the BAR_ManyToOne trial.

rm(list=ls())
ptm=Sys.time()
library(base);library(MCMCpack);library(MASS);library(dplyr);
set.seed(1234)
options(digits=5)

#============================================================================#
Pu=0.932
scenario=1;     #1-4
fn1="DBCD"      #AR;DBCD
fn2="C2"        #ER: C1=0; AR:C1=1;C2=n/2N
fn3="control"   #control：delta=0 ;control_10: delta=10
fn4="C3"        #DBCD:C3=2

# set the file path 

desktop_path = file.path('D:/Rcode/BAR_ManyToOne/result/')
source(file.path("D:/Rcode/BAR_ManyToOne/wei_modelsparameter.R")) #parameters setting
source(file.path("D:/Rcode/BAR_ManyToOne/function.R"))            # functions
source(file.path("D:/Rcode/BAR_ManyToOne/wei_F30_trial.R"))    #the proposed trials

Sys.time()-ptm
