###===================================================###
methodFN<-function(mu){
  if(fn3=="control"){
    asign1=length(which(mu$mua>=mu$mub | mu$mua>=mu$muc))/Z
    asign2=length(which(mu$mub>mu$mua))/Z
    asign3=length(which(mu$muc>mu$mua))/Z}
  if(fn3=="control_10"){
    asign1=length(which(mu$mua+10>=mu$mub | mu$mua+10>=mu$muc))/Z
    asign2=length(which(mu$mub>mu$mua+10))/Z
    asign3=length(which(mu$muc>mu$mua+10))/Z}
  asign=c(asign1,asign2,asign3)
  return(asign)
}




### AR / DBCD ### 
###===================================================###
AR<-function(fn2,asign,n,N){
  if(fn2=="C1"){c=1}
  if(fn2=="C2"){c=n/(2*N)}
  prob=asign^c
  prob
}
DBCD<-function(fn4,asign,ni,n,N){
  if(fn4=="C3"){c=2}
  y=asign;x=ni/n
  if(x==0||x==1){prob=1-x}
  else{prob=y*((y/x)^c)}
  prob
}

useFN<-function(fn1,fn2,fn4,asign1,asign2,asign3,na,nb,nc,n,N){
  if(fn1=="AR"){
    aa=AR(fn2,asign1,n,120)
    bb=AR(fn2,asign2,n,120)
    cc=AR(fn2,asign3,n,120)
  }
  if(fn1=="DBCD"){
    a=AR(fn2,asign1,n,120)
    b=AR(fn2,asign2,n,120)
    c=AR(fn2,asign3,n,120)
    asign1=a/(a+b+c)
    asign2=b/(a+b+c)
    asign3=c/(a+b+c)
    aa=DBCD(fn4,asign1,na,n,120)
    bb=DBCD(fn4,asign2,nb,n,120)
    cc=DBCD(fn4,asign3,nc,n,120)
  }
  
  asign=c(aa/(aa+bb+cc),bb/(aa+bb+cc),cc/(aa+bb+cc))
  return(asign)
}
